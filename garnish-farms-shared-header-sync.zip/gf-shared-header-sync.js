/* Garnish Farms shared header sync
 * Include this file on non-Home pages after Supabase JS is loaded:
 * <script src="gf-shared-header-sync.js"></script>
 */
(function () {
  if (window.__gfSharedHeaderSyncStarted) return;
  window.__gfSharedHeaderSyncStarted = true;

  const SUPABASE_URL = 'https://odtalucpwmxcydxbypke.supabase.co';
  const SUPABASE_ANON_KEY = 'sb_publishable_FjnWmIJaLHxxf0nIOB1SSQ_gOMJxbrm';

  const dot = document.getElementById('syncDot');
  const label = document.getElementById('syncStatus');

  function setState(state, message) {
    if (dot) dot.className = 'sync-dot' + (state ? ' ' + state : '');
    if (label) label.textContent = message;
  }

  function put(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = String(value);
  }

  function norm(value) {
    return String(value == null ? '' : value)
      .trim()
      .toLowerCase()
      .replace(/[\s_-]+/g, ' ');
  }

  async function syncHeader() {
    setState('', 'Syncing...');

    try {
      if (!window.supabase ||
          typeof window.supabase.createClient !== 'function') {
        throw new Error('Supabase client library unavailable');
      }

      const client = window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_ANON_KEY
      );

      const { data, error } = await client
        .from('batches')
        .select('id,batch_id,container,stage,quantity,status,harvest_weight');

      if (error) throw error;

      if (!Array.isArray(data) || data.length === 0) {
        setState('', 'Connected · No batch records returned');
        return;
      }

      // Match the Home page's current active-record rule:
      // exclude known terminal states; retain blank/unknown statuses.
      const active = data.filter(batch =>
        ![
          'inactive', 'harvested', 'contaminated',
          'archived', 'discarded', 'deleted'
        ].includes(norm(batch.status))
      );

      const quantity = batch => Math.max(0, Number(batch.quantity) || 0);

      const jars = active
        .filter(batch => norm(batch.container) === 'jar' &&
                         norm(batch.stage) !== 'fruiting')
        .reduce((sum, batch) => sum + quantity(batch), 0);

      const bags = active
        .filter(batch => norm(batch.container) === 'bag' &&
                         norm(batch.stage) !== 'fruiting')
        .reduce((sum, batch) => sum + quantity(batch), 0);

      const fruiting = active
        .filter(batch => norm(batch.stage) === 'fruiting')
        .reduce((sum, batch) => sum + quantity(batch), 0);

      const totalYield = data.reduce(
        (sum, batch) => sum + (Number(batch.harvest_weight) || 0),
        0
      );

      // Keep the batch total consistent with the Home header (all rows).
      put('kpi-active', data.length);
      put('kpi-jars', jars);
      put('kpi-bags', bags);
      put('kpi-fruiting', fruiting);
      put('kpi-yield', totalYield.toFixed(1));
      put('header-total-farm-yield-val', totalYield.toFixed(1) + ' lbs');

      setState('connected', 'Cloud Synced · ' + data.length + ' batches');
    } catch (error) {
      console.error('Garnish Farms shared header sync failed:', error);
      setState('error', 'Cloud Sync Error');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncHeader, { once: true });
  } else {
    syncHeader();
  }
})();
