GARNISH FARMS — SHARED HEADER SYNC

Purpose
-------
One reusable header-sync routine for:
- list.html
- strain.html
- upcoming.html
- harvest.html
- activities.html
- yield.html
- settings.html

It refreshes the existing header elements:
- syncDot / syncStatus
- kpi-active (total batch rows)
- kpi-jars
- kpi-bags
- kpi-fruiting
- header-total-farm-yield-val (when present)

Status behavior
---------------
- Gray: checking, or query returned no batch rows.
- Green: Supabase batch query succeeded and returned records.
- Red: Supabase library, connection, or query failed.

Important
---------
This package has NOT been installed in GitHub Pages. The GitHub connection
rejected the attempted write with HTTP 403, so no repository files were changed.

Installation
------------
1. Upload gf-shared-header-sync.js to the repository root on branch main.
2. On each of the seven pages listed above, add this line immediately before
   </body>:

   <script src="gf-shared-header-sync.js"></script>

3. Ensure the page already loads the Supabase JavaScript library before this
   script. The current seven pages do.
4. Commit the page edits and wait for GitHub Pages to deploy.
5. Test each page. The header should show the same batch/jar/bag/fruiting
   counts and sync state.

This intentionally does not modify index.html. Home keeps its own existing
data-loading and rendering flow. The known Home production-section issue
remains separate and is not claimed fixed by this shared-header package.

Count rules
-----------
The calculations mirror the Home header logic:
- Batch count = all rows returned from batches.
- Jars = active rows with container Jar and stage other than Fruiting.
- Bags = active rows with container Bag and stage other than Fruiting.
- Fruiting = active rows whose stage is Fruiting.
- Active excludes inactive, harvested, contaminated, archived, discarded,
  and deleted. Blank or unfamiliar statuses are retained.
